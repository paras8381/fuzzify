# Federated ANFIS for Smart Grid Fault Detection

This project implements a federated learning framework with ANFIS for smart grid fault detection. Each edge node trains locally and contributes to a global model using FedAvg. See `evaluation.py` for results.

## How to Run
```bash
pip install -r requirements.txt
python generate_data.py
python fuzzify.py
python federated_training.py
python evaluation.py
```